-------------------------------------------Bluewirez Alpha v0.5-----------------------------------------------

A Sort-of Electricity Simulator
Created By Chromium Studios
Made Using GameMaker 8.1 Standard

CONTROLS:

Left Click: Place wires (hold to continue placing wires) /interact with menu buttons
Right Click: Interact (with switches)
Space: Place switch
C: Place Generator
V: Place Light
B: Place Clocker
N: Place Laser Producer

ITEM DESCRIPTIONS:

Wires: transports power. Grey when unpowered, blue when powered. Can be powered by switches, clockers, generators, and other wires.
Switches: Right click to turn on/off. When on, produces power.
Generators: Always produce power.
Light: When powered, turns a lighter shade of grey and produces light.  Can be powered by switches, clockers, generators, and wires.
Clocker: Once powered, begins oscillating between producing power and not producing power at regular intervals. Can be powered by switches, clockers, generators, and wires. Grey when not producing power, blue when producing power. Once powered, cannot be unpowered.
Laser Producer: When powered, shoots blue lasers (always to the right) that destroy everything in their path except other lasers and laser producers. Grey when unpowered, blue when powered. Can be powered by switches, clockers, generators, and other wires.

NOTES/BUGS:

-Move your mouse around to move to viewing port in the Lab (gridded main game area).
-Once in the Lab, there is currently no way to exit without closing the game entirely. Working on a fix.
-PROJECTS ARE DELETED ONCE THE GAME IS CLOSED. There is no way currently to save builds. Working on a fix.
-I am always working on adding more items.

This game is completely free, but please do not redistribute without my permission!
Any support you can give me including sharing this game over various social networks is appreciated.
